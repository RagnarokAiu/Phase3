from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import boto3
import os
import uuid

app = FastAPI(title="Document Service")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# S3 Configuration
S3_BUCKET = os.getenv("DOCUMENT_BUCKET", "document-service-storage-o90hv5")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

s3_client = boto3.client(
    's3',
    aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
    aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
    aws_session_token=os.getenv("AWS_SESSION_TOKEN"),
    region_name=AWS_REGION
)

@app.get("/")
async def root():
    return {"service": "document-service", "status": "running"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    try:
        file_ext = os.path.splitext(file.filename)[1]
        file_id = str(uuid.uuid4())
        s3_key = f"{file_id}{file_ext}"

        s3_client.upload_fileobj(
            file.file,
            S3_BUCKET,
            s3_key
        )

        return {
            "status": "success",
            "file_id": file_id,
            "filename": file.filename,
            "s3_key": s3_key,
            "message": "File uploaded successfully"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
